Happy Hacking Sensible UK Layout
--------------------------------

This is a keyboard layout for Windows. Run setup.exe to install it.

Once installed, select it inside the Regional and Language Options control panel applet.

This is a standard UK keyboard layout with some changes:
	* Shift-2 generates " (standard)
	* Shift-' generates ' (standard)
	* Shift-3 generates # (non-standard) (see note 1)
	* AltGr-3 generates � (non-standard)

AltGr is the right Alt key, at least if you have SW4 set to 0, which is the default.

This layout was created with the MS Keyboard Layout Creator 1.4

Happy Hacking :)

http://jamesoff.net/site/projects/windows/happy-hacking-uk-layout/

-- 
Note 1: Since this is a UK keyboard layout, Shift-3 generates HASH not POUND or GATE or OCTOTHORPE. AltGr-3 generates POUND, and don't you dare mix them up.

